Digital Bridge Track 2 - 3G Low-Data Offline Study Pack
Includes compressed Opus audio, semantic HTML, and transcripts.
Saves 98.7% bandwidth vs 205MB HD video.
